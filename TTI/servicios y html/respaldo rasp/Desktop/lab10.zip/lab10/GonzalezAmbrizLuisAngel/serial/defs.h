#ifndef DEFS_H
#define DEFS_H

#define NUM_HILOS 	4
#define DIMASK 		3
#define PUERTO 		8000
#define EVER 		1
#endif
