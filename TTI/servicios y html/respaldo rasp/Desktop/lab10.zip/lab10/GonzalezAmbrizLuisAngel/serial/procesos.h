#ifndef PROCESOS_H
#define PROCESOS_H

int config_serial ( char *, speed_t );


char validacion_de_datos(char *arreglo_dato);
void obtenerdatos(char * arreglo_dato);


#endif