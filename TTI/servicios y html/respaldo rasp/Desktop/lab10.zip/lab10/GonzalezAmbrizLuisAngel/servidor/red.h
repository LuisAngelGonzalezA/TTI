
#ifndef RED_H
#define RED_H

//void * funHilo( void *idh );

void mandar(int cd);

#endif