package com.example.eduardo.helios.utileria



enum class Numeros(val valor:Int){
    CERO(0), UNO(1)
}